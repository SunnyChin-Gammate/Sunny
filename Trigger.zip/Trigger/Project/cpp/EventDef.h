#ifndef __EVENTDEF__
#define __EVENTDEF__


enum {
};

#endif
