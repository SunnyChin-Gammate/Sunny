IMPLEMENT_CLASS_INFO(ACTION_NAME)
ACTION_NAME::ACTION_NAME(void)
{
}

ACTION_NAME::~ACTION_NAME(void)
{
}

bool ACTION_NAME::init()
{
    return true;
}

void ACTION_NAME::done()
{
    CCLOG("ACTION_NAME::done");
}

void ACTION_NAME::serialize(const rapidjson::Value &val)
{
    CCLOG("ACTION_NAME::serialize");
}

void ACTION_NAME::removeAll()
{
	CCLOG("ACTION_NAME::removeAll");
}

