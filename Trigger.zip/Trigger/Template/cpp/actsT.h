class ACTION_NAME : public cocostudio::BaseTriggerAction
{
    DECLARE_CLASS_INFO
public:
     ACTION_NAME(void);
     virtual ~ACTION_NAME(void);

     virtual bool init();
     virtual void done();
	 virtual void serialize(const rapidjson::Value &val);
     virtual void removeAll();
};
