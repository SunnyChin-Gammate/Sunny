class CONDITION_NAME : public cocostudio::BaseTriggerCondition
{
    DECLARE_CLASS_INFO
public:
     CONDITION_NAME(void);
     virtual ~CONDITION_NAME(void);

     virtual bool init();
     virtual bool detect();
	 virtual void serialize(const rapidjson::Value &val);
     virtual void removeAll();
};
