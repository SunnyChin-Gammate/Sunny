IMPLEMENT_CLASS_INFO(CONDITION_NAME)
CONDITION_NAME::CONDITION_NAME(void)
{
}

CONDITION_NAME::~CONDITION_NAME(void)
{
}

bool CONDITION_NAME::init()
{
    return true;
}

bool CONDITION_NAME::detect()
{
    CCLOG("CONDITION_NAME::detect");
    return true;
}

void CONDITION_NAME::serialize(const rapidjson::Value &val)
{
    CCLOG("CONDITION_NAME::serialize");
}

void CONDITION_NAME::removeAll()
{
	CCLOG("CONDITION_NAME::removeAll");
}

